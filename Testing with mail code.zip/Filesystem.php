<!-- File Handling -->

<?php
$file = "newfile.txt";

// Check the existence of file
if (file_exists($file)) {
////  File Reading
//    $handle = fopen($file, "r") or die("ERROR: Cannot open the file.");
//    $content = fread($handle, filesize($file));
//    fclose($handle);
//    $mfile = file_get_contents($file);
//    echo $mfile;

////  File Write
//    $data = "First Sentence.";
//    $data2 = "second Sentence.";
//    $handle = fopen($file, "w") or die("ERROR: Cannot open the file.");
//    fwrite($handle, $data) or die ("ERROR: Cannot write the file.");
//    fclose($handle);
//    echo "Data written to the file successfully.";
//    echo file_get_contents($file);

////  String of data to be written
//    $data = "The quick brown fox jumps over the lazy dog.";
//    file_put_contents($file, $data, FILE_APPEND) or die("ERROR: Cannot write the file.");
//    echo "Data written to the file successfully. <br>";
//    echo " Here is the New Data : ".file_get_contents($file);

////    File Name Change
//    if(rename($file, "newfile.txt")){
//        echo "File renamed successfully.";
//    } else{
//        echo "ERROR: File cannot be renamed.";
//    }

////  File Removing
//    $file = "aas.txt";
//    if(file_exists($file)){
//        if(unlink($file)){
//            echo "File removed successfully.";
//        } else{
//            echo "ERROR: File cannot be removed.";
//        }
//    } else{
//        echo "ERROR: File does not exist.";
//    }

////  Creating a file using PHP Script
//    $content = "some text here";
//    $fp = fopen("myText.txt","wb");
//    fwrite($fp,$content);
//    fclose($fp);


} else {
    echo "ERROR: File does not exist.";
}

?>
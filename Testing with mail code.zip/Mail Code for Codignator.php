<?php

    $mailconfig = array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail host address', // Change it Yours
        'smtp_port' => 465,
        'smtp_user' => 'abc@gmail.com', // change it to yours
        'smtp_pass' => '******', // change it to yours
        'mailtype'  => 'html',
        'charset'   => 'iso-8859-1',
        'wordwrap'  => 'true'
    );
    $msg = '<!DOCTYPE html>
	<html lang="en">
	<head>
	  <title>Mail Code</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	</head>
	<body>
	  
	<div class="container">
	  <div class="row">
	  Dear Team,
	<br>
	  Something went wrong, Not working , kindly check it. 
	  <br>
	  </div>
	</div>
	
	</body>
	</html>
	';
    $this->load->library('email', $mailconfig);
    $this->email->set_newline("\r\n");
    $this->email->from("abc@gmail.com", "******"); // Change it Yours
    $this->email->to('tomail'); // Change it Yours
    $this->email->cc('ccmail'); // Change it Yours
    $this->email->subject("**IMPORTANT NOTIFICATION**");
    $this->email->message($msg);
    $this->email->send();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Simple Image Gallery</title>
    <style type="text/css">
        .img-box {
            display: inline-block;
            text-align: center;
            margin: 0 15px;
        }
    </style>
</head>
<body>
<?php

$images = array("newfile.txt", "myText.txt"); // Change the file names and the format as your wish.

foreach ($images as $image) {
    echo '<div class="img-box">';
    echo '<p><a href="download.php?file=' . urlencode($image) . '" style="text-decoration: none">' . $image . '</a></p>'; // Chane the file directory where is the download backend code.
    echo '</div>';
}
?>
</body>
</html>